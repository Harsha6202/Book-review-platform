package com.example.review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
